import { useSelector } from "react-redux"
import { useLocation } from "react-router-dom"
import { BaseUrl } from "../Config/baseUrl"
import axios from "axios"
import { toast } from "react-toastify"






const CheckOutPage = ()=>{
   
    const {state} = useLocation()
    console.log(state)

    function getSubtotal(){
        let tmp = state
        let total = 0
        for(let i=0;i<tmp.length;i++){
          total = total + parseInt(Number(tmp[i].p_data.price) - (Number(tmp[i].p_data.price)*Number(tmp[i].p_data.discount))/100) * tmp[i].quantity
        }
        return total
       }
return(

   <>
   <div class = "container" style={{width :"80%",dispaly:"flex",justifyContent:"center",alignItems:"center"}}>
    <div class="col-sm-4">
    <div class="card" style={{width: "100%"}}>
  <div class="card-body">
    <h5 class="card-title" style={{textAlign:"left"}}>Order Summary</h5>
    <hr></hr>
    <p class="card-text">

    <div class="row">
    <div class="col-sm">
     Items :
    </div>
    <div class="col-sm">
  
    </div>
    </div>
    <div class="row">
    <div class="col-sm">
      One of three columns
    </div>
    <div class="col-sm">
      One of three columns
    </div>
    </div>
    <div class="row">
    <div class="col-sm">
      One of three columns
    </div>
    <div class="col-sm">
      One of three columns
    </div>
    
  </div>
    </p>
    <a href="#" class="btn btn-primary"  style={{width:"100%",backgroundColor:"#FFD814",color:"black",border:"none"}}>Proceed to Buy</a>
  </div>
</div>
    </div>
</div>
   </>
)
}

export default CheckOutPage