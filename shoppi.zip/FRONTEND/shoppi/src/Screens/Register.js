import {Link} from 'react-router-dom'
import { toast } from 'react-toastify'
import {useEffect,useState} from 'react'
import axios from 'axios'
import { BaseUrl } from '../Config/baseUrl'
import Lottie from 'react-lottie';
import * as animationData from '../assets/Animation - 1695535451321.json'


const defaultOptions = {
  loop: true,
  autoplay: true, 
  animationData: animationData,
  rendererSettings: {
    preserveAspectRatio: 'xMidYMid slice'
  }
  }


function Resgister(){

  const [loading,setLoading] =useState(false)
  const [values ,setValues] = useState({
    name:"",
    email:"",
    mobile:"",
    password:"",


  })

  const handleInput = (e)=>{
    setValues({...values, [e.target.name] : e.target.value})
  }

  const handleSubmit = ()=>{
    
    
      var reg =  /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      if(! reg.test(values.email)){
        toast.error("Please Enter The Valid Email")
      }
      else if(values.password.length < 6){
        toast.error("Please Enter atleast 6 Digit Password.")
      }
      else{
        setLoading(true)
        axios.post(BaseUrl + 'register', values).then((res)=>{
          toast.success(res.data.message)
          setLoading(false)
        }).catch((err)=>{
          toast.error(err.response.data.message)
          setLoading(false)
          
        })
      

    }
  }

    return(
        <>
        
        {loading == true ?
        <>
        <Lottie options={defaultOptions}
              height={400}
              width={400}
              isStopped={false}
              isPaused={false}/>
              <h5 style={{color:'green', textAlign:'center'}}>Please Wait While We are Fetching Data For You:)</h5>
        </>
              
              :
        <div class="container">
         <div class="form-group">
    <label for="l1">Name</label>
    <input type="text" name="name" onChange={handleInput} class="form-control" id="l1" placeholder="Enter your Name"/>
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="l2">Email address</label>
    <input type="email" name="email"onChange={handleInput} class="form-control" id="l2" placeholder="Enter your Email"/>
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="l3">Mobile</label>
    <input type="email" name="mobile" onChange={handleInput}class="form-control" id="l3" placeholder="Enter your Mobile"/>
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  
  <div class="form-group">
    <label for="l4">Password</label>
    <input type="password" name="password" onChange={handleInput}class="form-control" id="l41" placeholder="Enter your Password"/>
  </div>
  <br></br>
  <button type="submit" onClick={handleSubmit}class="btn btn-primary">Submit</button>
  <br></br>

        <i><h5>Already Have an Account? &nbsp; <Link to={'/login'}>Login Here</Link></h5></i>

        
  </div>
        
}
        
        </>

  

    )


}


export default Resgister