import { useState } from "react"
import axios from 'axios'
import { BaseUrl } from '../Config/baseUrl'
import Lottie from 'react-lottie';
import * as animationData from '../assets/Animation - 1695535451321.json'
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
const defaultOptions = {
    loop: true,
    autoplay: true, 
    animationData: animationData,
    rendererSettings: {
      preserveAspectRatio: 'xMidYMid slice'
    }
    }




function ForgotPassword(){
    const navigate = useNavigate()

    const [values, setValues] = useState({
        email : "",
        showForm2 : false,
        loading : false,
        otp : "",
        new_pass : "",
        resend : false
    })
    function handleInput(e){
        
        setValues({...values ,[e.target.name] : e.target.value})
    }

    function handleLogin(){
        var reg =  /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      if(! reg.test(values.email)){
        toast.error("Please Enter The Valid Email")
      }
      else{
        setValues({...values , ['loading'] : true})
        axios.post(BaseUrl + 'send_otp',values).then((res)=>{
            toast.success(res.data.message)
            setValues({...values , ['loading'] : false, ['showForm2'] : true,['resend'] : false})
            
        }).catch((err)=>{
            toast.error(err.response.data.message)
            setValues({...values , ['loading'] : false})
        })
      }


    }

    function handleOTP(){
        setValues({...values , ['loading'] : true})
        axios.post(BaseUrl + 'verify_otp',values).then((res)=>{
            toast.success(res.data.message)
            setValues({...values , ['loading'] : false, ['showForm2'] : false})
            navigate('/login')
        }).catch((err)=>{
            if(err.response.data.status == 403){

                setValues({...values , ['loading'] : false , ['resend'] : true })
            }
            toast.error(err.response.data.message)
            setValues({...values , ['loading'] : false})
        })

    }



return(

    <>
    {values.loading == true ?
    <>
        <Lottie options={defaultOptions}
              height={400}
              width={400}
              isStopped={false}
              isPaused={false}/>
              <h5 style={{color:'green', textAlign:'center'}}>Please Wait While We are Fetching Data For You:)</h5>
        </>
        :
    <>
    
    {values.showForm2 == false ?
    <div class="container">
    <button disabled style={{backgroundColor:'black',color:"white"}}type="submit" class="btn btn-primary">RESET YOUR PASSWORD</button>
    <br>
    </br>
    <br></br>
<div class="form-group">
<label for="l1">Email address</label>
<input type="email" name="email" onChange={handleInput} class="form-control" id="l1"  placeholder="Enter email"/>

</div>
<br></br>
<button onClick={handleLogin} type="submit" class="btn btn-primary">Submit</button>
    <br></br>

   
    </div>
:
    <div class="container">
    <button disabled style={{backgroundColor:'black',color:"white"}}type="submit" class="btn btn-primary">VERIFY OTP</button>
    <br>
    </br>
    <br></br>
    {values.resend == false ?
    <>
<div class="form-group">
<label for="l1">Enter OTP</label>
<input type="number" name="otp" onChange={handleInput} class="form-control" id="l1"  placeholder="Enter OTP"/>

</div>
<div class="form-group">
<label for="l1">Enter New Password</label>
<input type="text" name="new_pass" onChange={handleInput} class="form-control" id="l1"  placeholder="Enter Password"/>

</div>
<br></br>
<button onClick={handleOTP} type="submit" class="btn btn-primary">Submit</button>
    <br></br>
    </>
    :
    <>
    <br></br>
    <button onClick={handleLogin} type="submit" class="btn btn-primary">Verify OTP</button>
    <br></br>
    </>
    
    }
    </div>
}
</>
}
    
    </>






)


}

export default ForgotPassword