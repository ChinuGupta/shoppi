function Contact(){
    return(
    
        <h1>this is contact page.</h1>
    )
    
    }
    
    export default Contact