import { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { BaseUrl } from "../Config/baseUrl"
import axios from "axios"
import { toast } from "react-toastify"
import Lottie from 'react-lottie';
import * as animationData from '../assets/Animation - 1696338339044.json'
import { useNavigate } from "react-router-dom"

const defaultOptions = {
  loop: true,
  autoplay: true, 
  animationData: animationData,
  rendererSettings: {
    preserveAspectRatio: 'xMidYMid slice'
  }
  }

function MyCart(){

    const [cartData , setCartData] = useState([])
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const u_id = useSelector((state) => state.LoginReducer.login_data.u_id)
    function getMyCart(){
        axios.get(BaseUrl + 'get-my-detailed-cart',{params : {u_id : u_id}}).then((result)=>{
            console.log(result.data)
            setCartData(result.data.data)
            dispatch({type : 'CART_COUNT' , data : result.data.count})
        })
       }

       const handleQuanIncre = (x,y)=>{
        let dy = {
          cd_id : x,
          quan : Number(y) +1
        }
        axios.post(BaseUrl +"update-quantity" ,dy).then((res)=>{
          toast.success(res.data.message)
          getMyCart()
        }).catch((err)=>{
          toast.error(err.response.data.message)
        })
       }
       const handleQuanDecre = (x,y)=>{
        let dy = {
          cd_id : x,
          quan : Number(y) -1
        }
        if((y-1)==0)
        {
          let c = window.confirm("Do You Want TO Remove This Item ?")
          if(c==true)
          {
            axios.post(BaseUrl +"update-quantity" ,dy).then((res)=>{
              toast.success(res.data.message)
              getMyCart()
            }).catch((err)=>{
              toast.error(err.response.data.message)
            })
          }
        }
        else{
          axios.post(BaseUrl +"update-quantity" ,dy).then((res)=>{
            toast.success(res.data.message)
            getMyCart()
          }).catch((err)=>{
            toast.error(err.response.data.message)
          })
        }
        
       }

       function getSubtotal(){
        let tmp = cartData
        let total = 0
        for(let i=0;i<tmp.length;i++){
          total = total + parseInt(Number(tmp[i].p_data.price) - (Number(tmp[i].p_data.price)*Number(tmp[i].p_data.discount))/100) * tmp[i].quantity
        }
        return total
       }
       useEffect(()=>{
        getMyCart()
       },[])
       
  const handleCheckout=()=>{
    let rd = Math.floor(Math.random()*56733234567) 
    navigate('/checkoutPage/' + rd, {state : cartData})
  }

    return(
      <div style={{width:'80%', marginLeft:'150px'}}>
        {cartData.length > 0 ?
      <>
  <div class="row">
    <div class="col-sm-8">

      {cartData.map((el,i)=>(


   
    <div class="row" style={{padding:'5px'}}>
    <div class="col-sm-4">
    <img src={el.p_data.image} class="card-img-top" alt="..."/>
    </div>
    <div class="col-sm-8">
    <h5 class="card-title">{el.p_data.name}</h5>
    <p class="card-title" style={{fontSize:35, fontWeight:"bold"}}>{el.p_data.discount > 0 ?<span style={{color:"red", fontSize:25, fontWeight:"bold"}}>-{el.p_data.discount}%</span>:""} &nbsp; 
                     &#8377; {(Number(el.p_data.price) - (Number(el.p_data.price)*Number(el.p_data.discount))/100).toFixed(2)}
                    </p>

                    <p class="card-title" style={{fontSize:15}}>M.R.P. <s>&#8377; {el.p_data.price}</s></p>
<div style={{padding:"10px"}}>
  <div class="row">
    <div class="col-sm-5" style={{textAlign:"right"}}>
    <button  class="btn btn-danger" onClick={()=>handleQuanDecre(el._id ,el.quantity)}style={{fontSize:20 ,fontWeight:"bold"}}>-</button>
    </div>
    <div class="col-sm-1" style={{fontSize:20 ,fontWeight:"bold"}}>
      {el.quantity}
    </div>
    <div class="col-sm-5">
      
      <button  class="btn btn-success"  onClick={()=>handleQuanIncre(el._id ,el.quantity)}style={{fontSize:20 ,fontWeight:"bold"}}>+</button>
    </div>
  </div>
</div>

    </div>
    <hr></hr>
  </div>

))}
    </div>
    <div class="col-sm-4">
    <div class="card" style={{width: "100%"}}>
  <div class="card-body">
    <h5 class="card-title">Subtotal (1 item): {getSubtotal()}</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-primary" onClick={handleCheckout} style={{width:"100%",backgroundColor:"#FFD814",color:"black",border:"none"}}>Proceed to Buy</a>
  </div>
</div>
    </div>
    
  </div>
  </>
  :
  <Lottie options={defaultOptions}
  height={400}
  width={400}
  isStopped={false}
  isPaused={false}/>
      }
  
  </div>
 
        )
}
export default MyCart