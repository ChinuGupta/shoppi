import {combineReducers} from 'redux'
import CountReducers from './CountReducer'
import LoginReducer from './LoginReducer'
import CartReducers from './CartReducer'



export default combineReducers({

CountReducers,
LoginReducer,
CartReducers

})