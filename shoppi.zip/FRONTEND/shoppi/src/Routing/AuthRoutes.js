import { Route,Routes } from "react-router-dom"

import Login from "../Screens/Login"
import Register from "../Screens/Register"
import ForgotPassword from "../Screens/ForgotPassword"

function AuthRoutes(){
return(
    <>
   
        <Routes>
            <Route path='/' element={<Login/>}/>
            <Route path='/register' element={<Register/>}/>
            <Route path='/login' element={<Login/>}/>
            <Route path='/frgt' element={<ForgotPassword/>}/>
            <Route path='*' element={<Login/>}/>
           
        </Routes>
        </>

)

}

export default AuthRoutes