import AllRoutes from "./AllRoutes"
import AuthRoutes from "./AuthRoutes"
import {useState} from 'react'
import { UseSelector, useSelector } from "react-redux"


function SwitchRouting(){
    {/*const [auth, setAuth] = useState(localStorage.getItem('auth'))*/}
    const auth = useSelector((state)=>state.LoginReducer.login_status ? state.LoginReducer.login_status : false)

    return(
        <>
        {/*localStorage.getItem('auth') == 'false' ?<AuthRoutes/> :<AllRoutes/>*/}

        {auth ? <AllRoutes/> : <AuthRoutes/>}
        
        </>



    )


}

export default SwitchRouting