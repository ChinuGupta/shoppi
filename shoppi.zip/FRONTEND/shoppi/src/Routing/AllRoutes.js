import { Route,Routes } from "react-router-dom"
import Home from "../Screens/Home"
import About from "../Screens/About"
import Contact from "../Screens/Contact"
import NavBar from "../Layout/NavBar"
import ViewProduct from "../Screens/ViewProduct"
import MyCart from "../Screens/MyCart"
import CheckOutPage from "../Screens/CheckOut"


function AllRoutes(){
return(
    <>
    <NavBar/>
        <Routes>
            <Route path='/' element={<Home/>}/>
            <Route path='/about' element={<About/>}/>
            <Route path='/contact' element={<Contact/>}/>
            <Route path='*' element={<Home/>}/>
            <Route path='/viewProduct/:id' element={<ViewProduct/>}/>
            <Route path='/mycart' element={<MyCart/>}/>
            <Route path='/checkoutPage/:id' element={<CheckOutPage/>}/>
        </Routes>
        </>

)

}

export default AllRoutes