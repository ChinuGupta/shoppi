import {createStore,applyMiddleware} from 'redux'
import CombineReducers from '../reducers/CombineReducers'
import thunk from 'redux-thunk'

 
const persistedState = localStorage.getItem('reduxStore') ? JSON.parse(localStorage.getItem('reduxStore')) : {}




const store = createStore(
    CombineReducers,
    persistedState,
    applyMiddleware(thunk)
 )

 export default store