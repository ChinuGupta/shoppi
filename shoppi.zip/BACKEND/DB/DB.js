const mongoose = require('mongoose');


mongoose.connect('mongodb://127.0.0.1/STP-07-07' , {useNewUrlParser: true})



const db = mongoose.connection


db.once('open' ,()=>{console.log("Succesfully connected with database.")})
db.on('error' ,()=>{console.log("Not connected with database.")})


module.exports = db