const express = require('express')
const router = express.Router()
const controller = require('../Contollers/UserControllers')

router.post('/send_otp',controller.getotp)

router.post('/register', controller.addUser)

router.post('/login', controller.login)

router.post('/verify_otp', controller.verifyOtpAndChangePassword)

router.get('/get-all-products',controller.getAllProduct)

router.post('/add-to-cart',controller.AddToCart)

router.get('/get-my-cart',controller.GetMyCart)
router.get('/get-my-detailed-cart',controller.getDetailedCartData)
router.post('/update-quantity',controller.handleQuantity)
router.post('/purchase-order',controller.PurchaseOrder)




module.exports = router