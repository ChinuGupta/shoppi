const express = require('express');
const router = express.Router()
const adminController = require('../Contollers/AdminController')



router.post('/Add_product', adminController.AddProduct)






module.exports = router