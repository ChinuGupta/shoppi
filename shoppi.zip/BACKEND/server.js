const express = require('express')
const app = express()
const PORT = 8123
const bodyParser = require('body-parser')
const myRoutes = require('./Routes/UserRoutes')
const adminRoute = require('./Routes/AdminRoutes')
const db = require('./DB/DB')
const cors = require('cors')

app.use(cors())

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended : true}))


app.use('/',myRoutes)
app.use('/admin',adminRoute)


 



app.listen(PORT,()=>{
    console.log(`Server is running on port ${PORT}`)
})