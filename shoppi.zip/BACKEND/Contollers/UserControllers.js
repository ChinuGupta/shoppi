const UserSchema = require('../Schemas/user')
const bcrypt = require('bcrypt')
const nodemailer = require("nodemailer");
const otpSchema = require('../Schemas/otp')
const productSchema = require('../Schemas/product')
const CartSchema = require('../Schemas/Cart')
const OrderSchema =  require('../Schemas/Orders')
const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 465,
        secure: true,
        auth: {
          // TODO: replace `user` and `pass` values from <https://forwardemail.net>
          user: "non96382@gmail.com",
          pass: "aopdcriinwyqxtlj",
        },
});

exports.GetMyCart = (req,res)=>{
        const {u_id} = req.query
        CartSchema.find({u_id : u_id}).then((result)=>{
                res.status(200).send({ status : 200 ,data : result, count : result.length})
        }).catch((err)=>{
                res.status(500).send({status : 500, message :"Something went wrong. || Please TRy Again"})
        })
}

exports.handleQuantity = (req,res)=>{
        const {cd_id , quan} = req.body
        if(quan !== 0)
        {
                CartSchema.updateOne({_id : cd_id}, {$set : {quantity : quan}}).then((r1)=>{
                        if(r1.modifiedCount == 1)
                        {
                                res.status(200).send({ status : 200 ,message : "Quantity Updated"})
                        }
                        else{
                                res.status(400).send({ status : 400 ,message : "Try Again"})
                        }
                }).catch((err)=>{
                        console.log(err)
              
                        res.status(500).send({status : 500, message :"Something went wrong. || Please TRy Again"})
        })
}
else{
        CartSchema.deleteOne({_id : cd_id}).then((r1)=>{
                if(r1.deletedCount == 1)
                {
                        res.status(200).send({ status : 200 ,message : "Item Removed"})
                }
                else{
                        res.status(400).send({ status : 400 ,message : "Try Again"})
                }
        }).catch((err)=>{
                console.log(err)
      
                res.status(500).send({status : 500, message :"Something went wrong. || Please TRy Again"})
})
}
}

exports.getDetailedCartData = (req,res)=>{
        const {u_id} = req.query
        CartSchema.find({u_id : u_id}).then(async(result)=>{
                for(let i = 0; i<result.length;i++){
                        let pd = await productSchema.findOne({_id : result[i].p_id})
                        result[i]._doc['p_data'] = pd
                }
                res.status(200).send({ status : 200 ,data : result, count : result.length})
        }).catch((err)=>{
                console.log(err)
                res.status(500).send({status : 500, message :"Something went wrong. || Please TRy Again"})
        })
}

exports.AddToCart = (req,res)=>{
        const {p_id ,u_id } = req.body
        CartSchema.insertMany({p_id : p_id , u_id : u_id , quantity : 1, time : Number(new Date(Date.now()))}).then((r1)=>{
                if(r1.length > 0){
                        res.status(200).send({ status : 200 , message : "Product Successfully Added into Cart."})
                }
                else{
                        res.status(500).send({status : 500, message :"Something went wrong. || Please TRy Again"})
                }
        }).catch((err)=>{
                res.status(500).send({status : 500, message :"Something went wrong. || Please TRy Again"})
        })

}

exports.login = (req,res)=>{
        const {email , password} = req.body 

        UserSchema.find({email : email}).then((r1)=>{
                
                if(r1.length>0){
                        bcrypt.compare(password, r1[0].password, function(err,status){
                                if(err){
                                        res.status(500).send({status : 500, message :"Something went wrong."})
       
                                }
                                else{
                                        if(status == true){
                                                res.status(200).send({status : 200,data: { name:r1[0].name, email:r1[0].email, mobile:r1[0].mobile , u_id : r1[0]._id},   message : "Login Succesfully."})  
                                        }
                                        else{
                                                res.status(500).send({status : 500, message :"Incorrect password."})

                                        }
                                }
                        })
                }
                else{
                        res.status(400).send({status : 400, message :"You are not registered user || please register first. "}) 
                }
        }).catch((err)=>{
                
                res.status(500).send({status : 500, message :"Something went wrong."})

        })


}

exports.verifyOtpAndChangePassword = (req,res)=>{
        var{email , otp, new_pass}  = req.body
        UserSchema.find({email : email}).then((r1)=>{
                if(r1.length>0){
                        otpSchema.find({email : email}).then((r2)=>{
                                if(r2.length>0){
                                        if(r2[0].otp == otp){
                                                let t = Number(new Date())
                                                let tmp = (t - Number(r2[0].time))/1000
                                                if(tmp>30){
                                                        res.status(403).send({status : 403, message :"Your OTP is expired. || please generate a new OTP."})
                                                }
                                                else{
                                                        bcrypt.genSalt(10, function(err,salt){
                                                                if(err){
                                                                        res.status(500).send({status : 500, message :"Something went wrong."})    
                                                                }
                                                                else{
                                                                        bcrypt.hash(new_pass , salt, function(err,hash){
                                                                                if(err){
                                                                                        res.status(500).send({status : 500, message :"Something went wrong."})    
                                                                                }
                                                                                else{
                                                                                        UserSchema.updateOne({email : email} , {$set : {password : hash}}).then((r3)=>{
                                                                                                if(r3.matchedCount == 1){
                                                                                                        otpSchema.deleteOne({email : email}).then((r4)=>{
                                                                                                                if(r4.deletedCount == 1){
                                                                                                                        transporter.sendMail({
                                                                                                                                from: '"Node-web 👻" <non96382@gmail.com.com>', // sender address
                                                                                                                                to: email, // list of receivers
                                                                                                                                subject: "Password Changed", // Subject line
                                                                                                                                text: "Hello"+r1[0].name, // plain text body
                                                                                                                                html: `<h3>Your Password has reset just now.</h3>`, // html body
                                                                                                                              }).then((my_res)=>{
                                                                                                                                if(my_res.messageId){
                                                                                                                                        res.status(200).send({status : 200, message : "Your Password has reset Successfully."})
                                                                                                                                }
                                                                                                                                else{
                                                                                                                                        res.status(500).send( {status : 500, message : "Something went wrong || Please try again."})       
                                                                                                                                }
                                                                                
                                                                                                                              }).catch((err)=>{
                                                                                                                                res.status(500).send( {status : 500, message : "Something went wrong || Please try again."})
                                                                                                                              })
                                                                                                                        res.status(200).send({status : 200, message : "Your Password has reset Successfully."}) 
                                                                                                                }
                                                                                                                else{
                                                                                                                        res.status(500).send({status : 500, message :"Something went wrong."})
                                                                                                                }

                                                                                                        }).catch((err)=>{
                                                                                                                res.status(500).send({status : 500, message :"Something went wrong."})
                                                                                                
                                                                                                        })
                                                                                                        
                                                                                                }
                                                                                                else{
                                                                                                        res.status(400).send({status : 400, message :"Something went wrong."})
                                                                                                }
                                                                                        }).catch((err)=>{
                                                                                                res.status(500).send({status : 500, message :"Something went wrong."})
                                                                                
                                                                                        })
                                                                                }
                                                                        } )
                                                                }
                                                        })
                                                }

                                        }
                                        else{
                                                res.status(400).send({status : 400, message :"Incorrect OTP."}) 
                                        }
                                }
                                else{
                                        res.status(400).send({status : 400, message :"Something went wrong."})
                                }
                        }).catch((err)=>{
                res.status(500).send({status : 500, message :"Something went wrong."})

        })
                }
                else{
                        res.status(400).send({status : 400, message :"You are not registered user || please register first. "})   
                }

        }).catch((err)=>{
                res.status(500).send({status : 500, message :"Something went wrong."})

        })
}

exports.getotp = (req,res)=>{
        var {email} = req.body
        var otp = Math.floor(Math.random()*87637).toString().padStart(6,"0")
        otpSchema.deleteOne({email : email}).then((d1)=>{
                UserSchema.find({email : email}).then((r1)=>{
                        if(r1.length>0){
                                otpSchema.insertMany({time : Number(new Date()) , email : r1[0].email , otp : otp }).then((r2)=>{
                                        if(r2.length>0){
                                                transporter.sendMail({
                                                        from: '"Node-web 👻" <non96382@gmail.com.com>', // sender address
                                                        to: email, // list of receivers
                                                        subject: "Password Reset (node web)", // Subject line
                                                        text: "Hello"+r1[0].name, // plain text body
                                                        html: `<h3>Your 6 digit OTP is ${otp}</h3>`, // html body
                                                      }).then((my_res)=>{
                                                        if(my_res.messageId){
                                                                res.status(200).send({status : 200, message : "OTP Sent Successfully."})
                                                        }
                                                        else{
                                                                res.status(500).send( {status : 500, message : "Something went wrong || Please try again."})       
                                                        }
        
                                                      }).catch((err)=>{
                                                        res.status(500).send( {status : 500, message : "Something went wrong || Please try again."})
                                                      })
                                        }
                                        else{
                                                res.status(400).send({status : 400, message :"Something went wrong. || Try Again."})
                                        }
        
                                }).catch((err)=>{
                                        console.log(err)
                                        res.status(500).send({status : 500, message :"Something went wrong."}) 
                                })
                        }
                        else{
                                res.status(400).send({status : 400, message :"You are not registered user || please register first. "}) 
                        }
                }).catch((err)=>{
                        console.log(err)
                        res.status(500).send({status : 500, message :"Something went wrong."})
        
        
                })
        }).catch((err)=>{
                res.status(500).send({status : 500, message :"Something went wrong."})
        })
        



}
exports.getForm = (req,res)=>{
    res.send(
            `
            <form method='post' action='/test'>
            <input placeholder='Enter the Name' name='name'/>
            <input placeholder='Enter the Email' name='email'/>
            <input placeholder='Enter the Mobile' name='mobile'/>
            <input placeholder='Enter the Password' type="password" name='password'/>
            <button type='submit'>check</button>
            </form>
            `
)}

    exports.addUser = (req,res)=>{
        const {name, email, mobile, password} = req.body

        bcrypt.genSalt(10 , function(err,salt){
                if(err){
                        res.status(500).send({status : 500, message :"Something went wrong."}) 
                }
                else{
                        bcrypt.hash( password, salt, function( err, hash){
                                if(err){
                                        res.status(500).send({status : 500, message :"Something went wrong."}) 
                                }
                                else{
                                        UserSchema.insertMany([{name : name, email :email, mobile :mobile, password : hash}]).then((result)=>{
                                                console.log(result)
                                                if(result.length > 0){
                                                        transporter.sendMail({
                                                                from: '"Node-web 👻" <non96382@gmail.com.com>', // sender address
                                                                to: email, // list of receivers
                                                                subject: "Node_web registration", // Subject line
                                                                text: "Hello"+name, // plain text body
                                                                html: "<h3>Your registration has successfully done</h3>", // html body
                                                              }).then((my_res)=>{
                                                                if(my_res.messageId){
                                                                        res.status(200).send({status : 200, message : "User Register Succesfully."})
                                                                }
                                                                else{
                                                                        res.status(500).send( {status : 500, message : "User Registration failed. || Please try again."})       
                                                                }

                                                              }).catch((err)=>{
                                                                res.status(500).send( {status : 500, message : "User Registration failed. || Please try again."})
                                                              })
                                                            
                                                
                                                }
                                                else{
                                                        res.status(500).send( {status : 500, message : "User Registration failed. || Please try again."})
                                                }
                                               }).catch((err)=>{
                                                console.log(err.name)
                                                console.log(err.code)
                                                console.log(err.message)
                                        
                                               
                                                if(err.code == 11000){
                                                        res.status(400).send({status:400 , message : `User already exist with this ${err.message.split('{')[1].split(':')[0]} : ${err.message.split('{')[1].split(':')[1].replaceAll('"', '').replace('}','')}` })
                                                }
                                                else if(err.name == 'ValidationError'){
                                                        res.status(400).send({status : 400 , message : `${err.message.split(":")[1]} is required`})
                                                }
                                                else{
                                        
                                                        res.status(500).send({status : 500, message :"Something went wrong."})
                                                }
                                               })
                                }   
                        })
                }
        })

       
       
}



exports.getAllProduct = (req,res)=>{
        productSchema.find({}).then((result)=>{
                if(result.length > 0){
                        res.status(200).send({status : 200, data : result})
                }
                else{
                        res.status(200).send({status : 200, data : []})
                }
}).catch((err)=>{
        res.status(500).send({status : 500, message :"Something went wrong while Fetching Products."})
})
}

exports.PurchaseOrder = (res,req)=>{
        const {o_data , u_id , u_name} = req.body
        let ord_num = Number(Math.floor(Math.random() * 4567457).toString().padStart(6,'0'))

        OrderSchema.insertMany({u_id : u_id , o_data : o_data , ord_id : ord_num , time : new Date(Date.now())}).then(async(result)=>{
                if(result.length > 0)
                {
                        for(let i = 0 ; i < o_data.length ; i++)
                        {
                                try{
                                        let st = await CartSchema.deleteOne({_id : o_data[i]._id})
                                }catch(err)
                                {
                                      res.status(400).send({status : 400, message :"Something went wrong while Process your Order."})
                                      break
                                }
                        }
                        transporter.sendMail({
                                from: '"Node-web 👻" <non96382@gmail.com.com>', // sender address
                                to: email, // list of receivers
                                subject: "Node_web Order Process", // Subject line
                                text: "Hello"+u_name, // plain text body
                                html: `<h3>Your Order has successfully Processed with Order Number ${ord_num}</h3>`, // html body
                              }).then((my_res)=>{
                                if(my_res.messageId){
                                        res.status(200).send({status : 200, message : "Order Generated Succesfully."})
                                }
                                else{
                                        res.status(500).send( {status : 500, message : "Order Not Generated. || Please try again."})       
                                }

                              }).catch((err)=>{
                                res.status(500).send( {status : 500, message : "User Registration failed. || Please try again."})
                              })


                }else{
                        res.status(400).send({status : 400, message :"Something went wrong while Process your Order."})
                }
        }).catch((err)=>{
                console.log(err)
        res.status(500).send({status : 500, message :"Something went wrong while Process your Order."})
})
}