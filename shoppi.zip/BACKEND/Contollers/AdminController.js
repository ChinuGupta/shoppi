const Product = require('../Schemas/product')


exports.AddProduct = (req,res)=>{
    var {name, price, discount, description, image, category, brand} = req.body
   Product.insertMany({name : name, price : price, discount: discount, description : description, image : image, category : category, brand : brand}).then((result)=>{
    if(result.length > 0){
        res.status(200).send({status : 200, message: "Product Added Successfully."})
    }
    else{
        res.status(400).send({status : 400, message: "Failed to Add Product. || Please try again"})
    }
   }).catch((err)=>{
    console.log(err)
    res.status(500).send({status : 500, message: "Something Went Wrong || Please try again"})

   })
}