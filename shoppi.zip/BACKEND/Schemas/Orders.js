const mongoose = require('mongoose')



const OrdersSchema = new mongoose.Schema({
    u_id: {
        type : String,
        required : true
  
    },
    ord_id: {
        type : String,
        required : true
  
    },
     o_data: {
        type : String,
        required : true
  
    },
   
    time: {
        type : Number,
        required : true
    },
    status : {
        type : Number,
        default : 0,
        // 0=>pending , 1=> dispatched , 2=>deliverd
        required : true
    }
    

})

const Order = mongoose.model("Orders" ,OrdersSchema)
module.exports = Order